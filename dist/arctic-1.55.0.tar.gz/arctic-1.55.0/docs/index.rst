.. arctic documentation master file

arctic
===============================

.. toctree::
   :maxdepth: 4

   autodoc/arctic

.. automodule:: arctic


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
